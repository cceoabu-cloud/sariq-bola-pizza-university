import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  signInWithEmailAndPassword,
  signOut,
  createUserWithEmailAndPassword,
  onAuthStateChanged
} from "firebase/auth";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  serverTimestamp
} from "firebase/firestore";
import { auth, db } from "./firebase";
import { BookOpen, GraduationCap, LogOut, Lock, UserPlus, Users, PlayCircle, ClipboardCheck } from "lucide-react";
import "./style.css";

const COURSES = [
  { id: "pizza-maker", name: "Pizza Maker", roles: ["pizza_maker", "universal", "trainer", "manager", "filial_rahbari"], desc: "Xamir, sous, pishirish, standart va sifat nazorati." },
  { id: "kassir", name: "Kassir", roles: ["kassir", "universal", "trainer", "manager", "filial_rahbari"], desc: "Kassa, mijoz bilan muloqot, iiko, chek va savdo madaniyati." },
  { id: "razdacha", name: "Razdacha", roles: ["razdacha", "universal", "trainer", "manager", "filial_rahbari"], desc: "Buyurtmani yig‘ish, tekshirish va mijozga topshirish standarti." },
  { id: "moyka", name: "Moyka", roles: ["moyka", "universal", "trainer", "manager", "filial_rahbari"], desc: "Idish yuvish, sanitariya, tozalik va xavfsizlik qoidalari." },
  { id: "yetkazib-beruvchi", name: "Yetkazib beruvchi", roles: ["yetkazib_beruvchi", "universal", "trainer", "manager", "filial_rahbari"], desc: "Yetkazish standarti, mijoz bilan aloqa va vaqt nazorati." },
  { id: "universal", name: "Universal", roles: ["universal", "trainer", "manager", "filial_rahbari"], desc: "Bir nechta lavozimni biladigan xodimlar uchun umumiy kurslar." },
  { id: "trainer", name: "Traner", roles: ["trainer", "manager", "filial_rahbari"], desc: "Yangi xodimni o‘rgatish, tekshirish va baholash." },
  { id: "manager", name: "Manager", roles: ["manager", "filial_rahbari"], desc: "Smena boshqaruvi, KPI, nazorat va hisobotlar." },
  { id: "filial-rahbari", name: "Filial rahbari", roles: ["filial_rahbari"], desc: "Filial natijalari, standartlar, rahbarlik va tizimli nazorat." }
];

const ROLE_LABELS = {
  pizza_maker: "Pizza Maker",
  kassir: "Kassir",
  razdacha: "Razdacha",
  moyka: "Moyka",
  yetkazib_beruvchi: "Yetkazib beruvchi",
  universal: "Universal",
  trainer: "Traner",
  manager: "Manager",
  filial_rahbari: "Filial rahbari"
};

function App() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        const snap = await getDoc(doc(db, "users", firebaseUser.uid));
        setProfile(snap.exists() ? snap.data() : null);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  if (loading) return <div className="center">Yuklanmoqda...</div>;
  if (!user) return <LoginPage />;
  if (!profile) return <NoProfilePage />;

  return <Dashboard user={user} profile={profile} />;
}

function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function login(e) {
    e.preventDefault();
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      setError("Login yoki parol xato. Qaytadan tekshiring.");
    }
  }

  return (
    <div className="loginPage">
      <div className="loginCard">
        <div className="brandIcon"><GraduationCap size={42} /></div>
        <h1>Sariq Bola Pizza University</h1>
        <p>Xodimlar uchun ichki o‘quv platformasi</p>
        <form onSubmit={login}>
          <label>Email login</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="xodim@sariqbola.uz" type="email" required />
          <label>Parol</label>
          <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Parol" type="password" required />
          {error && <div className="error">{error}</div>}
          <button type="submit"><Lock size={18} /> Kirish</button>
        </form>
      </div>
    </div>
  );
}

function NoProfilePage() {
  return (
    <div className="center page">
      <h2>Profil topilmadi</h2>
      <p>Bu login Firebase Auth’da bor, lekin Firestore users bazasida profil yo‘q.</p>
      <button onClick={() => signOut(auth)}>Chiqish</button>
    </div>
  );
}

function Dashboard({ user, profile }) {
  const [activeCourse, setActiveCourse] = useState(null);

  const visibleCourses = useMemo(() => {
    return COURSES.filter((course) => course.roles.includes(profile.role));
  }, [profile.role]);

  if (activeCourse) {
    return <CoursePage course={activeCourse} profile={profile} onBack={() => setActiveCourse(null)} />;
  }

  return (
    <div className="app">
      <Header profile={profile} />
      <main className="container">
        <section className="hero">
          <div>
            <h1>Assalomu alaykum, {profile.fullName || user.email}</h1>
            <p>Sizning lavozimingiz: <b>{ROLE_LABELS[profile.role] || profile.role}</b></p>
          </div>
          <div className="heroStat">
            <span>{visibleCourses.length}</span>
            <small>ochiq kurs</small>
          </div>
        </section>

        <section className="grid">
          {visibleCourses.map((course) => (
            <div className="courseCard" key={course.id}>
              <BookOpen size={30} />
              <h3>{course.name}</h3>
              <p>{course.desc}</p>
              <button onClick={() => setActiveCourse(course)}>Kursga kirish</button>
            </div>
          ))}
        </section>

        {(profile.role === "manager" || profile.role === "filial_rahbari") && <AdminPanel />}
      </main>
    </div>
  );
}

function Header({ profile }) {
  return (
    <header className="header">
      <div className="logo"><GraduationCap /> SBP University</div>
      <div className="headerRight">
        <span>{profile.filial || "Filial belgilanmagan"}</span>
        <button className="ghost" onClick={() => signOut(auth)}><LogOut size={17} /> Chiqish</button>
      </div>
    </header>
  );
}

function CoursePage({ course, profile, onBack }) {
  const lessons = [
    { id: 1, title: "1-dars: Kirish", type: "Matn", body: "Bu yerga o‘zingiz dars matnini yozasiz." },
    { id: 2, title: "2-dars: Video dars", type: "Video", body: "Bu yerga YouTube/Firebase video link qo‘yiladi." },
    { id: 3, title: "3-dars: Test", type: "Test", body: "Bu yerga test savollari qo‘shiladi." }
  ];

  return (
    <div className="app">
      <Header profile={profile} />
      <main className="container">
        <button className="back" onClick={onBack}>← Orqaga</button>
        <section className="courseHero">
          <h1>{course.name}</h1>
          <p>{course.desc}</p>
        </section>
        <div className="lessonList">
          {lessons.map((lesson) => (
            <div className="lesson" key={lesson.id}>
              {lesson.type === "Video" ? <PlayCircle /> : lesson.type === "Test" ? <ClipboardCheck /> : <BookOpen />}
              <div>
                <h3>{lesson.title}</h3>
                <span>{lesson.type}</span>
                <p>{lesson.body}</p>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

function AdminPanel() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("pizza_maker");
  const [filial, setFilial] = useState("");
  const [users, setUsers] = useState([]);
  const [message, setMessage] = useState("");

  async function loadUsers() {
    const snap = await getDocs(collection(db, "users"));
    setUsers(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  }

  useEffect(() => {
    loadUsers();
  }, []);

  async function createEmployee(e) {
    e.preventDefault();
    setMessage("");
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await setDoc(doc(db, "users", cred.user.uid), {
        fullName,
        email,
        role,
        filial,
        createdAt: serverTimestamp(),
        active: true
      });
      setMessage("Xodim yaratildi. Eslatma: admin qayta login qilishi kerak bo‘lishi mumkin.");
      setFullName(""); setEmail(""); setPassword(""); setFilial("");
      await loadUsers();
    } catch (err) {
      setMessage("Xatolik: email band bo‘lishi yoki parol 6 belgidan kam bo‘lishi mumkin.");
    }
  }

  return (
    <section className="admin">
      <h2><Users /> Admin panel</h2>
      <p>Bu joydan xodim loginlarini yaratish mumkin. Keyingi versiyada dars/test qo‘shish paneli ham bo‘ladi.</p>
      <form className="adminForm" onSubmit={createEmployee}>
        <input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Xodim F.I.Sh" required />
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email login" type="email" required />
        <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Parol, kamida 6 belgi" type="password" required />
        <input value={filial} onChange={(e) => setFilial(e.target.value)} placeholder="Filial nomi" required />
        <select value={role} onChange={(e) => setRole(e.target.value)}>
          {Object.entries(ROLE_LABELS).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
        </select>
        <button><UserPlus size={18} /> Xodim yaratish</button>
      </form>
      {message && <div className="notice">{message}</div>}
      <div className="userList">
        {users.map((u) => (
          <div className="userRow" key={u.id}>
            <b>{u.fullName}</b>
            <span>{u.email}</span>
            <small>{ROLE_LABELS[u.role] || u.role} · {u.filial}</small>
          </div>
        ))}
      </div>
    </section>
  );
}

createRoot(document.getElementById("root")).render(<App />);
